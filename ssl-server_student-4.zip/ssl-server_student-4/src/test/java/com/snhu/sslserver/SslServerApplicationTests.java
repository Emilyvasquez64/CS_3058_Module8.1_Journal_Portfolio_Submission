package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@WebMvcTest(ChecksumController.class)
class SslServerApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void checksumRouteReturnsExpectedHash() throws Exception {
        // expected SHA-256 hash for "Hello World Check Sum!"
    	String expectedHash = "ab2aca08da294c82c67ae581bb5d309004220bece2ee07a84e13902029daa2cb";

        mockMvc.perform(get("/checksum"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Hello World Check Sum!")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString(expectedHash)));
    }
}
