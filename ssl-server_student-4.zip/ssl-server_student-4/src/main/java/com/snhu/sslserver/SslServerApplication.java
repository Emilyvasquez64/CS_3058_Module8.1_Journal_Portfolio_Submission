package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ChecksumController {

    @GetMapping("/hash")// change from "/checksum"
    public String getChecksums() throws NoSuchAlgorithmException {
        // Original data
        String originalData = "Hello World Check Sum!";
        String originalChecksum = calculateSHA256(originalData);

        // Your unique data
        String uniqueData = "Emily Vasquez - Refactored code for HTTPS protocol on localhost hash";
        String uniqueChecksum = calculateSHA256(uniqueData);

        // Build combined output
        StringBuilder sb = new StringBuilder();
        sb.append("Original Data: ").append(originalData)
          .append("\nChecksum (SHA-256): ").append(originalChecksum)
          .append("\n\nYour Unique Data: ").append(uniqueData)
          .append("\nChecksum (SHA-256): ").append(uniqueChecksum);

        return sb.toString();
    }

    // Helper method to compute SHA-256 checksum
    private String calculateSHA256(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = md.digest(data.getBytes());

        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}

